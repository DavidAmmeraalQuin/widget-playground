<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Flaticon CSS --> 
        <link rel="stylesheet" href="assets/fonts/flaticon.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Owl Carousel Min CSS --> 
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <!-- Nice Select Min CSS --> 
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">


        <title>Huisartsenpraktijk Rolde</title>

        <!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
		
    </head>
    <body>
        <!-- Pre Loader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="spinner"></div>
                </div>
            </div>
        </div>
        <!-- End Pre Loader -->
		
		   <!-- Top Header Start -->
        <header class="top-header top-header-bg">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-8">
                        <div class="header-left">
                            <div class="header-left-card">
                                <ul>
                                    <li>
										
                                        <div class="head-icon">
                                            <i class='bx bx-phone'></i>
                                        </div>
                                        <a href="tel:0592-248052">Drs. vd Linden - 0592-248052</a>
                                    </li>
    
									
                                    <li>
                                        <div class="head-icon">
                                            <i class='bx bx-phone'></i>
                                        </div>
                                        <a href="tel:0592-242913">Drs. G.J. Radstaak - 0592-242913</a>
                                    </li>
									
									  <li>
                                        <div class="head-icon">
                                            <i class='bx bx-phone'></i>
                                        </div>
                                        <a href="tel:0592-241225">Drs. J.S. Sporrel- 0592-241225</a>
                                    </li>
									
									
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4">
                        <div class="header-right">
                            <div class="top-social-link">
                                <ul>
                                  
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Top Header End -->


       	

      <!-- Start Navbar Area -->
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/logo.png" alt="Huisartsenpraktijk Rolde logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/logo.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
								
                               
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link">
                                        Home
                                    </a>
                                </li>
								
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Praktijk 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-spreekuur.php" class="nav-link">
                                                Spreekuur
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-recepten.php" class="nav-link">
                                                Recepten
                                            </a>
                                        </li>
										
																		
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                                Inschrijven
                                            </a>
                                        </li>
										
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-over-ons.php" class="nav-link">
                                                Over ons
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-medewerkers.php" class="nav-link">
                                                Medewerkers
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-patientenenquete.php" class="nav-link">
                                                Patiëntenenquête
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-klachtenregeling.php" class="nav-link">
                                                Klachtenregeling
                                            </a>
                                        </li>
										
                                       
                                      
                                    </ul>
                                </li>

                              

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Afspraken 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-maken.php" class="nav-link">
                                                Afspraak maken 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-afzeggen.php" class="nav-link">
                                                Afspraak afzeggen 
                                            </a>
                                        </li>
										 <li class="nav-item">
                                            <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank" class="nav-link">
                                                Check je gezondheidsklacht 
                                            </a>
                                        </li>
                                      
                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Contact
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Adresgegevens 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Contactgegevens
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Openingstijden 
                                            </a>
                                        </li>
										<li class="nav-item">
                                            <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank" class="nav-link">
                                                Chat met de praktijk 
                                            </a>
                                        </li>
                                    </ul>
                                </li>
								
								  <li class="nav-item">
                                     <a href="mijngezondheidnet.php" class="nav-link">
                                        MijnGezondheid.net
                                    </a>
                                </li>

								  <li class="nav-item">
                                     <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                        Formulieren
                                    </a>
                                </li>

                              
								
								
                            </ul>

                           

                             
                            </div>
                        </div>
                    </nav>
                </div>
            </div>

            <div class="side-nav-responsive">
                <div class="container">
                   
                 

                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->     

        <!-- Emergency Area -->
        <div class="emergency-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="emergency-content">
                            <h3>Spoedgevallen:</h3>
                             <h3>Levensbedreigende situaties <a href="tel:112">bel 112</a>!
<p><br>
<h3>Bij verwondingen of spoedeisende klachten bel onze spoedlijn <a href="tel:0592-242204"> 0592-242204</a></h3>
<h3>U kunt onze spoedlijn bellen tussen 08.00 en 17.00 uur.</h3>
<br>
							<h3>Voor niet spoedeisende gevallen kunt u bellen: <br>
							 <a href="tel:0592-248052">Drs. vd Linden • 0592-248052</a><br>
							<a href="tel:0592-242913">Drs. G.J. Radstaak • 0592-242913</a><br>
							<a href="tel:0592-241225">Drs. J.S. Sporrel • 0592-241225</a><br>
							</p>
                            
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
        <!-- Emergency Area End -->

    
   		
		  <!-- Prescription Area Two -->
        <div class="prescription-area-two prescription-bg-3 ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="prescription-content">
                            <h2>Check je gezondheidsklacht.</h2>
                            <p> Check eerst je gezondheidsklacht om te zien of een afspraak maken nodig is.</p>
                            <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank" class="prescription-btn">
                                Check je gezondheidsklacht
                                <i class="flaticon-doctor"></i>
                            </a>
							&nbsp;&nbsp;&nbsp;
							 <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank" class="prescription-btn">
                                Chat met de praktijk
                                <i class="flaticon-doctor"></i>
                            </a>
							
                        </div>
                    </div>
                </div>
            </div>
       
        </div>
        <!-- Prescription Area Two End -->
		
     
		
  <!-- Pharma download Area -->
       <div class="blog-area blog-area-item pt-45 pb-40">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Het gemak van MijnGezondheid.net</h2>
                <div class="section-icon">
                        <div class="icon">
                            <i class="flaticon-dna"></i>
                        </div>
                    </div>
                    <p>
                       MijnGezondheid.net is een online omgeving waarmee u eenvoudig en snel gezondheidszaken bij uw huisarts of apotheek kunt regelen. U kunt meer informatie bekijken of als aanvulling op het patiëntenportaal MijnGezondheid.net kunt u de app MedGemak downloaden voor iOS of Android.
                    </p>
                </div>
                <div class="row pt-45">
					
					    <div class="col-lg-4 col-md-6">
                        <div class="blog-item">
                            <div class="blog-item-img">
                                <a href="https://home.mijngezondheid.net/ondersteuning/" target="_blank">
                                    <img src="assets/img/extra-info-mijngezondheid-net.jpg" alt="info mijngezondheid">
                                </a>
                            </div>
                        </div>
                    </div>

					
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-item">
                            <div class="blog-item-img">
                                <a href="https://apps.apple.com/nl/app/medgemak/id1263901022" target="_blank">
                                    <img src="assets/img/download-app-store.jpg" alt="download mijngezondheid app">
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="blog-item">
                            <div class="blog-item-img">
                                <a href="https://play.google.com/store/apps/details?id=nl.pharmapartners.medgemak&hl=nl" target="_blank">
                                    <img src="assets/img/download-google-play.jpg" alt="download mijngezondheid app">
                                </a>
                            </div>
                        </div>
                    </div>

     
                </div>
            </div>

        </div>
        <!-- Pharma Download End -->	
		
		
		
		
		
		    <!-- Faq Area -->
        <div class="faq-area faq-bg pt-45 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="faq-accordion">
                            <div class="section-title">
                                <span>FAQ</span>
                                <h2>Bezoek aan onze huisartsenpraktijk</h2>
                            </div>
                            <ul class="accordion">
								
								   <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class='bx bx-chevron-down'></i>
                                         Avond-, nacht- en weekenddienst
                                    </a>
    
                                    <div class="accordion-content">
                                        <p> 

Voor spoedgevallen buiten praktijkuren die niet kunnen wachten tot de eerstvolgende werkdag van onze praktijk, kun u contact opnemen met de huisartsenspoedpost via het digitaal spreekuur <a href="https://spreekuur.nl" target="_blank">Spreekuur.nl</a>
of <a href="tel:088-0504030">088 – 050 40 30</a>.
 <br><br>
<strong>Wanneer is het digitaal spreekuur bereikbaar voor spoed?</strong><br>
Doordeweeks tussen 17.00 en 21.30 uur.<br>
In het weekend tussen 08.00 tot 21.30 uur.
 <br><br>
<strong>Wanneer is de huisartsenspoedpost telefonisch bereikbaar voor spoed?</strong><br>
Doordeweeks tussen 17.00 en 08.00 uur de volgende ochtend.<br>
In het weekend tussen vrijdagmiddag 17.00 uur en maandagochtend 08.00 uur<br>
Op feestdagen 24 uur per dag.
 <br><br>
<strong>Alleen bij spoed!</strong><br>
Veel medische klachten en kleine verwondingen kunt u goed zelf behandelen. Daarvoor hoeft u niet naar de huisartsenspoedpost. De huisartsenspoedposten zijn écht bedoeld voor acute zorgvragen die niet kunnen wachten tot de eerstvolgende werkdag.
 <br><br>
Bezoek de website <a href="https://www.thuisarts.nl" title="Thuisarts" target="_blank">www.thuisarts.nl</a> of <a href="https://www.moetiknaardedokter.nl" target="_blank">www.moetiknaardedokter.nl</a>. Daar vindt u meer informatie over de behandeling van verschillende medische klachten.
 <br><br>
<strong>Alleen op afspraak<br>
</strong>Ga nooit zomaar of zonder afspraak naar een huisartsenspoedpost, maar bel altijd eerst voor overleg. U krijgt een deskundige triagist te spreken. Zo voorkomt u onnodig wachten voor uzelf en anderen.
 <br><br>
<strong>Voor meer informatie en locaties.<br>
</strong><a href="https://www.dokterdrenthe.nl/patienten/huisartsenspoedpost/locaties" target="_blank">Huisartsenspoedposten in Drenthe</a>
                                        </p>
                                    </div>
                                </li>
								
                           
                              

                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class='bx bx-chevron-down'></i>
                                       Hoe kan ik een afspraak maken?
                                    </a>
    
                                    <div class="accordion-content">
                                        <p> 
                                             Het spreekuur wordt gehouden op iedere werkdag.
Voor het spreekuur moet u altijd vooraf een afspraak maken. Voor afspraken bij voorkeur bellen tussen 8:00 uur en 10:30 uur. 
                                        </p>
                                    </div>
                                </li>

                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class='bx bx-chevron-down'></i>
                                        Wanneer kan ik bellen voor een uitslag?
                                    </a>
    
                                    <div class="accordion-content">
                                        <p> 
                                            Voor uitslagen kunt u bellen tussen 13:00 uur en 14.30 uur.

Dat heeft als voordeel dat u niet naar de praktijk hoeft te komen. U kunt de assistente vragen of uw huisarts u terug kan bellen. Zij zal dan vragen naar de reden van het contact, zodat de huisarts zich kan voorbereiden op het telefoontje. U kunt ook vragen stellen aan de assistente. Zij kan u vaak direct zelf helpen.

                                        </p>
                                    </div>
                                </li>

                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class='bx bx-chevron-down'></i>
                                       Wat als ik mijn afspraak vergeet of niet kom?
                                    </a>
    
                                    <div class="accordion-content">
                                        <p> 
                                           Indien u bij verhindering een afspraak niet minimaal 24 uur van te voren afzegt, of als u uw afspraak vergeet, dan zullen wij dat noteren. Indien dit nogmaals gebeurt dan zijn wij genoodzaakt het tarief dat voor deze afspraak geldt bij u in rekening te brengen. Let op! U kunt dit bedrag niet declareren bij uw zorgverzekeraar!
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="faq-counter-area">
                            <div class="row">
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Faq Area End -->

		
		 <!-- Prescription Area Two -->
        <div class="prescription-area-three prescription-bg-2 ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="prescription-content">
                            <h2>Wist u dat?</h2>
                            <p>Wij in periodes van grote drukte (rondom vakantie, met griep-epidemie), de medisch minder urgente zaken pas na enkele weken inplannen? Wij vragen hiervoor uw begrip!
 <br>
U kunt voor een <strong>afspraak</strong> de praktijk bellen op werkdagen tussen 8.00 en 10.00 uur.<br>
Voor het <strong>ochtendspreekuur kunt u enkele dagen van tevoren</strong> een afspraak maken.<br>
Voor het <strong>middagspreekuur is dit alleen mogelijk op de dag zelf</strong> zodat we altijd ruimte hebben voor acute zaken. </p>
                            <a href="huisartsenpraktijk-rolde-afspraak-maken.php" class="prescription-btn">
                                Lees meer
                                <i class="flaticon-doctor"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
       
        </div>
        <!-- Prescription Area Two End -->

		

      <!-- Service Details Area -->
        <div class="service-details-area pt-45 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="service-sidebar">
                           
						
							
							
                            <div class="service-categories">
                                <ul>
                                   <li>
                                        <a href="https://home.mijngezondheid.net/inloggen/" target="_blank">
                                            Inloggen MijnGezondheid.net
                                            <i class='bx bx-plus'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="huisartsenpraktijk-rolde-spreekuur.php">
                                            Spreekuur
                                            <i class='bx bx-plus'></i>
                                        </a>
                                        
                                    </li>
                                  
                                    <li>
                                        <a href="huisartsenpraktijk-rolde-recepten.php">
                                            Recepten
                                            <i class='bx bx-plus'></i>
                                        </a> 
                                        
                                    </li>
                                  
                                    <li>
                                        <a href="huisartsenpraktijk-rolde-afspraak-maken.php">
                                            Afspraak maken
                                            <i class='bx bx-plus'></i>
                                        </a>
                                    </li>
									
									 <li>
                                        <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank">
                                            Check je gezondheidsklacht
                                            <i class='bx bx-plus'></i>
                                        </a>
                                    </li>
									
									 <li>
                                        <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank">
                                            Chat met de praktijk
                                            <i class='bx bx-plus'></i>
                                        </a>
                                    </li>
                            
                                </ul>
                            </div>

                            <div class="service-open-hours">
                                <h3>Openingstijden</h3>
                                <ul>
                                    <li>
                                        Maandag
                                        <span>08:00 - 17:00 uur</span>
                                    </li> 
                                    <li>
                                        Dinsdag
                                        <span>08:00 - 17:00 uur</span>
                                    </li> 
                                    <li>
                                        Woensdag
                                        <span>08:00 - 17:00 uur</span>
                                    </li> 
                                    <li>
                                        Donderdag
                                        <span>08:00 - 17:00 uur</span>
                                    </li> 
                                    <li>
                                        Vrijdag
                                        <span>08:00 - 17:00 uur</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="services-article">
                        <div class="services-content">
                          <h2>De assistente</h2>
                                <p>
                                   
De assistente staat u als eerste te woord wanneer u met de praktijk belt. Ze maakt afspraken voor het spreekuur, de huisbezoeken en het telefonische spreekuur. Hiervoor kunt u bellen tussen 8.00 en 10.30 uur. Zij weet het antwoord op veel praktische vragen, bijvoorbeeld over verwijzingen en recepten. U kunt haar ook bellen voor de uitslag van urine- of bloedonderzoek.
							<br>
Urine kunt u voor 10.00 uur afgeven aan de assistente. Urine voor onderzoek graag zo vers mogelijk (binnen twee uur na lozing).
Voor urine-, laboratorium of röntgenuitslagen en inlichtingen over brieven van de specialist kunt u tussen 13.00 en 15.00 uur bellen met de assistente. Dit gaat altijd in overleg met, of in opdracht van uw huisarts.
U bent zelf verantwoordelijk voor het opvragen van uitslagen. Dit betekent dus dat u niet automatisch gebeld wordt over de uitslag van een bepaald onderzoek.
<br>
<strong>Verder kunt u bij de assistente terecht voor:
</strong><br>
+ herhaalrecepten<br>
+ het meten van de bloeddruk<br>
+ aanstippen van wratten<br>
+ verbinden van wonden<br>
+ oren uitspuiten<br>
+ hechtingen verwijderen<br>
+ zwangerschapstest<br>
+ urine onderzoek<br>
+ suiker- en Hb-controle<br>
+ uitstrijkjes (in het kader van het bevolkingsonderzoek)<br>
+ tapen van de enkels<br>
+ CVRM (Cardiovasculair Risicomanagement)<br>
+ vaccinaties<br>
+ verstrekken van informatiefolders


                                </p>
                        </div>
                      </div>
                    </div>
                </div>

              
            </div>
        </div>
        <!-- Service Details Area End -->
		
  <!-- Prescription Area Two -->
        <div class="prescription-area-three prescription-bg-2 ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="prescription-content">
                            <h2>Urinecontrole gewijzigd.</h2>
                            <p>De methode van urineonderzoek is gewijzigd. Wij testen uw urine voortaan via een geheel geautomatiseerd testapparaat. </p>
                            <a href="huisartsenpraktijk-rolde-urinecontrole.php" class="prescription-btn">
                                Lees meer
                                <i class="flaticon-doctor"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
       
        </div>
        <!-- Prescription Area Two End -->
	

  	  <!-- Footer Area -->
        <footer class="footer-area pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3>Contactgegevens</h3>
                            <p>Huisartsenpraktijk Rolde</p>
                            <ul class="footer-contact-list">
                               
                                   
                                  
                                       <a href="https://goo.gl/maps/f5cpJKq8mwQuQUN76" target="_blank"> Zuides 50A • 9451 KD Rolde</a>
                                 
                             
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="footer-widget">
                            <h3>AVG - Copyright</h3>
                            <ul class="footer-list">
                                <li>
                                    <a href="huisartsenpraktijk-rolde-privacyverklaring.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Privacyverklaring
                                    </a>
                                </li> 
                                <li>
                                    <a href="huisartsenpraktijk-rolde-disclaimer.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Disclaimer
                                    </a>
                                </li> 
                                
                             
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget">
                            <h3>Openingstijden</h3>
                            <ul class="open-hours-list">
                                <li>
                                    Ma. t/m Vr.
                                    08:00 - 17:00 uur
                                </li> 
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget ps-2">
                            <div class="footer-logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="Logo">
                                </a>
                            </div>
                            <p></p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->

        <!-- Copy-Right Area -->
        <div class="copy-right-area">
            <div class="container">
                <div class="copy-right-text text-center">
                    <p>
                        Copyright ©2021 Huisartsenpraktijk Rolde. :: Realisatie: 
                        <a href="https://www.blixxum.nl" target="_blank">Blixxum! Design</a> 
                    </p>
                </div>
            </div>
        </div>
        <!-- Copy-Right Area End -->

        <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Datepicker JS -->
        <script src="assets/js/datepicker.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
        
    </body>
</html>
