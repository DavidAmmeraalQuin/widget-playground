<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Flaticon CSS --> 
        <link rel="stylesheet" href="assets/fonts/flaticon.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Owl Carousel Min CSS --> 
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <!-- Nice Select Min CSS --> 
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">


        <title>Huisartsenpraktijk Rolde</title>

        <!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
		
    </head>
    <body>
        <!-- Pre Loader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="spinner"></div>
                </div>
            </div>
        </div>
        <!-- End Pre Loader -->

      	

      <!-- Start Navbar Area -->
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/logo.png" alt="Huisartsenpraktijk Rolde logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/logo.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
								
                               
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link">
                                        Home
                                    </a>
                                </li>
								
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Praktijk 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-spreekuur.php" class="nav-link">
                                                Spreekuur
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-recepten.php" class="nav-link">
                                                Recepten
                                            </a>
                                        </li>
										
																		
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                                Inschrijven
                                            </a>
                                        </li>
										
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-over-ons.php" class="nav-link">
                                                Over ons
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-medewerkers.php" class="nav-link">
                                                Medewerkers
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-patientenenquete.php" class="nav-link">
                                                Patiëntenenquête
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-klachtenregeling.php" class="nav-link">
                                                Klachtenregeling
                                            </a>
                                        </li>
										
                                       
                                      
                                    </ul>
                                </li>

                              

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Afspraken 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-maken.php" class="nav-link">
                                                Afspraak maken 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-afzeggen.php" class="nav-link">
                                                Afspraak afzeggen 
                                            </a>
                                        </li>
										 <li class="nav-item">
                                            <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank" class="nav-link">
                                                Check je gezondheidsklacht 
                                            </a>
                                        </li>
                                      
                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Contact
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Adresgegevens 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Contactgegevens
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Openingstijden 
                                            </a>
                                        </li>
										<li class="nav-item">
                                            <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank" class="nav-link">
                                                Chat met de praktijk 
                                            </a>
                                        </li>
                                    </ul>
                                </li>
								
								  <li class="nav-item">
                                     <a href="mijngezondheidnet.php" class="nav-link">
                                        MijnGezondheid.net
                                    </a>
                                </li>

								  <li class="nav-item">
                                     <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                        Formulieren
                                    </a>
                                </li>

                              
								
								
                            </ul>

                           

                             
                            </div>
                        </div>
                    </nav>
                </div>
            </div>

            <div class="side-nav-responsive">
                <div class="container">
                   
                 

                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        <!-- Inner Banner -->
        <div class="inner-banner inner-bg1">
            <div class="container">
                <div class="inner-title">
                    <h3>Over ons</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>Over ons</li>
                    </ul>
                </div>
            </div>
            <div class="inner-banner-shape">
               
            </div>
        </div
        <!-- Inner Banner End -->

       
            <!-- About Area -->
        <div class="about-area pt-45 pb-40">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/over-ons.jpg" alt="Huisartsenpraktijk Rolde">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="about-content">
                            <div class="section-title">
                                <span>Over ons</span>
                                <h2>Huisartsenpraktijk Rolde</h2>
                                <p>Binnen onze huisartsenpraktijk zijn 3 huisartsen werkzaam met elk hun eigen patiëntenkring. 
                                </p>
							
                            </div>
							
							
                          

                            <div class="about-card">
                                <i class='flaticon-doctor bg-two'></i>
                                <div class="content">
                                    <span>G. van der Linden</span>
                                    <p>Huisarts</p>
                                </div>
                            </div>
							
							  <div class="about-card">
                                <i class='flaticon-doctor bg-three'></i>
                                <div class="content">
                                    <span>G.J. Radstaak</span>
                                    <p>Huisarts</p>
                                </div>
                            </div>
							
							    <div class="about-card">
                                <i class='flaticon-doctor bg-one'></i>
                                <div class="content">
                                    <span>J.S. Sporrel </span>
                                    <p>Huisarts</p>
                                </div>
                            </div>
							
							
							
							<br>
	<p>Bij het maken van een afspraak zal de assistente vragen naar de reden van uw contact. Ze is daartoe opgeleid en doet dat om zo goed mogelijk een inschatting te maken van de aard en spoedeisendheid van uw klachten. De assistentes hebben, evenals de artsen, een beroepsgeheim.</p>
							<p>Wanneer het niet mogelijk is om zelf naar de praktijk te komen, dan kan de huisarts u ook thuis bezoeken. De assistente beoordeelt, eventueel samen met de huisarts, of een huisbezoek afgelegd wordt.</p>
							<p>Belt u de assistente tijdig wanneer een afspraak niet door kan gaan?</p>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Area End -->

			
			
  	  <!-- Footer Area -->
        <footer class="footer-area pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3>Contactgegevens</h3>
                            <p>Huisartsenpraktijk Rolde</p>
                            <ul class="footer-contact-list">
                               
                                   
                                  
                                       <a href="https://goo.gl/maps/f5cpJKq8mwQuQUN76" target="_blank"> Zuides 50A • 9451 KD Rolde</a>
                                 
                             
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="footer-widget">
                            <h3>AVG - Copyright</h3>
                            <ul class="footer-list">
                                <li>
                                    <a href="huisartsenpraktijk-rolde-privacyverklaring.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Privacyverklaring
                                    </a>
                                </li> 
                                <li>
                                    <a href="huisartsenpraktijk-rolde-disclaimer.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Disclaimer
                                    </a>
                                </li> 
                                
                             
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget">
                            <h3>Openingstijden</h3>
                            <ul class="open-hours-list">
                                <li>
                                    Ma. t/m Vr.
                                    08:00 - 17:00 uur
                                </li> 
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget ps-2">
                            <div class="footer-logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="Logo">
                                </a>
                            </div>
                            <p></p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->

        <!-- Copy-Right Area -->
        <div class="copy-right-area">
            <div class="container">
                <div class="copy-right-text text-center">
                    <p>
                        Copyright ©2021 Huisartsenpraktijk Rolde. :: Realisatie: 
                        <a href="https://www.blixxum.nl" target="_blank">Blixxum! Design</a> 
                    </p>
                </div>
            </div>
        </div>
        <!-- Copy-Right Area End -->

         <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Datepicker JS -->
        <script src="assets/js/datepicker.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
        
    </body>
</html>
