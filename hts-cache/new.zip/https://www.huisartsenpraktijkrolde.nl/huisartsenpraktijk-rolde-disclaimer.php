<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Flaticon CSS --> 
        <link rel="stylesheet" href="assets/fonts/flaticon.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Owl Carousel Min CSS --> 
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <!-- Nice Select Min CSS --> 
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">


        <title>Huisartsenpraktijk Rolde</title>

        <!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
		
    </head>
    <body>
        <!-- Pre Loader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="spinner"></div>
                </div>
            </div>
        </div>
        <!-- End Pre Loader -->

      	

      <!-- Start Navbar Area -->
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/logo.png" alt="Huisartsenpraktijk Rolde logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/logo.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
								
                               
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link">
                                        Home
                                    </a>
                                </li>
								
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Praktijk 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-spreekuur.php" class="nav-link">
                                                Spreekuur
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-recepten.php" class="nav-link">
                                                Recepten
                                            </a>
                                        </li>
										
																		
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                                Inschrijven
                                            </a>
                                        </li>
										
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-over-ons.php" class="nav-link">
                                                Over ons
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-medewerkers.php" class="nav-link">
                                                Medewerkers
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-patientenenquete.php" class="nav-link">
                                                Patiëntenenquête
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-klachtenregeling.php" class="nav-link">
                                                Klachtenregeling
                                            </a>
                                        </li>
										
                                       
                                      
                                    </ul>
                                </li>

                              

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Afspraken 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-maken.php" class="nav-link">
                                                Afspraak maken 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-afzeggen.php" class="nav-link">
                                                Afspraak afzeggen 
                                            </a>
                                        </li>
										 <li class="nav-item">
                                            <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank" class="nav-link">
                                                Check je gezondheidsklacht 
                                            </a>
                                        </li>
                                      
                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Contact
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Adresgegevens 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Contactgegevens
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Openingstijden 
                                            </a>
                                        </li>
										<li class="nav-item">
                                            <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank" class="nav-link">
                                                Chat met de praktijk 
                                            </a>
                                        </li>
                                    </ul>
                                </li>
								
								  <li class="nav-item">
                                     <a href="mijngezondheidnet.php" class="nav-link">
                                        MijnGezondheid.net
                                    </a>
                                </li>

								  <li class="nav-item">
                                     <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                        Formulieren
                                    </a>
                                </li>

                              
								
								
                            </ul>

                           

                             
                            </div>
                        </div>
                    </nav>
                </div>
            </div>

            <div class="side-nav-responsive">
                <div class="container">
                   
                 

                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        <!-- Inner Banner -->
        <div class="inner-banner inner-bg1">
            <div class="container">
                <div class="inner-title">
                    <h3>Disclaimer</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>Disclaimer</li>
                    </ul>
                </div>
            </div>
            <div class="inner-banner-shape">
               
            </div>
        </div
        <!-- Inner Banner End -->

       
      <!-- Privacy-Policy Area -->
        <div class="privacy-policy-area pt-100 pb-70">
            <div class="container">
               
                <div class="row pt-45">
                    <div class="col-lg-12">
                        <div class="single-content">
                           
                                  <h4>Disclaimer</h4>
									
                                    <div class="text">
										
<strong>Gebruikte afbeeldingen</strong><br>
Alle afbeeldingen op deze website hebben een standaard beeldlicentie via <a href="https://www.shutterstock.com/" title="Copyright afbeeldingen" target="_blank">shutterstock.com</a> en zodoende het recht om de afbeeldingen te gebruiken als digitale reproductie, ook op websites, in online advertenties, in sociale media, in mobiele advertenties, mobiele "apps", software, e-cards, e-publicaties, e-mailmarketing en in online media (inclusief op video-sharingdiensten zoals YouTube, Dailymotion, Vimeo, enzovoort).	<br>


<img src="assets/img/shutterstock/shutterstock_691984198.jpg" alt=""/> <br>
Item ID: 691984198: Contributor Stockfour / shutterstock.com<br> 										
										
<img src="assets/img/shutterstock/shutterstock_1080317963.jpg" alt=""/> <br>
Item ID: 1080317963: Contributor Pixel-Shote / shutterstock.com<br> 
																							
<img src="assets/img/shutterstock/shutterstock_2038814411.jpg" alt=""/><br>
Item ID: 2038814411: Contributor Marc Venema / shutterstock.com<br>
										
<img src="assets/img/shutterstock/shutterstock_1907021446.jpg" alt=""/><br>
Item ID: 1907021446: Contributor Jes2y.photo / shutterstock.com<br> 										
										
<img src="assets/img/shutterstock/shutterstock_1488343799.jpg" alt=""/><br>
Item ID: 1488343799: Contributor Ralf Liebhold / shutterstock.com<br> 
										
<img src="assets/img/shutterstock/shutterstock_1348222649.jpg" alt=""/><br>
Item ID: 1348222649: Contributor Visions-AD / shutterstock.com<br> 
										
<img src="assets/img/shutterstock/shutterstock_2044934987.jpg" alt=""/><br>
Item ID: 2044934987: Contributor CorinnaL / shutterstock.com<br><br>		

<img src="assets/img/shutterstock/shutterstock_173815904.jpg" alt=""/><br>
Item ID: 173815904: Contributor Image Point Fr / shutterstock.com<br><br>										
										
<strong>Aansprakelijkheid voor inhoud</strong><br>
De informatie op deze website is van algemene aard en is slechts bedoeld om Huisartsenpraktijk Rolde (verder genoemde als HPR) te introduceren. De inhoud is met de grootste zorg gemaakt. De juistheid, volledigheid en actualiteit van de inhoud kan HPR echter niet garanderen. HPR wijst erop dat de huidige inhoud geen individuele juridische, boekhoudkundige, fiscale, technische of andere technische informatie of aanbeveling vertegenwoordigt en niet geschikt is om een individuele raadpleging te vervangen, rekening houdend met de specifieke omstandigheden van individuele gevallen. Als dienstverlener is HPR niet verplicht om doorgegeven of opgeslagen informatie van derden te controleren of om omstandigheden te onderzoeken die wijzen op een illegale activiteit. Verplichtingen om het gebruik van informatie onder algemene wetgeving te verwijderen of blokkeren, blijven onverminderd van kracht. Een aansprakelijkheid in dit verband is echter alleen mogelijk vanaf de datum van kennis van een specifieke inbreuk. Na kennisgeving van toepasselijke schendingen zal ik deze inhoud onmiddellijk verwijderen.<br><br>
                                        
<strong>Aansprakelijkheid voor links</strong><br>
Ons aanbod bevat links naar externe websites van derden waarvan wij de inhoud niet kunnen beïnvloeden. Daarom kunnen wij geen aansprakelijkheid aanvaarden voor deze externe inhoud. De respectieve aanbieder of exploitant van de pagina's is altijd verantwoordelijk voor de inhoud van de gelinkte pagina's. De gekoppelde pagina's zijn gecontroleerd op mogelijke juridische overtredingen op het moment van koppelen. Illegale inhoud was niet herkenbaar op het moment van koppelen. Een permanente controle van de inhoud van de gelinkte pagina's is echter niet redelijk zonder concreet bewijs van een inbreuk. Na kennisgeving van overtredingen zullen we dergelijke links onmiddellijk verwijderen.<br>
<br>
                                        
<strong>Copyright</strong><br>
De inhoud die door de exploitant van de site is gemaakt en op deze pagina's werkt, valt onder de Nederlandse auteursrechtwetgeving. De reproductie, verwerking, distributie en elke vorm van exploitatie buiten de grenzen van het auteursrecht vereist de schriftelijke toestemming van de betreffende auteur of maker. Downloads en kopieën van deze site zijn alleen voor privé, niet-commercieel gebruik. Voor zover de inhoud aan deze zijde niet door de exploitant is gemaakt, worden de auteursrechten van derden in aanmerking genomen. Met name wordt inhoud van derden als zodanig geïdentificeerd. Als u nog steeds op de hoogte bent van een inbreuk op het auteursrecht, vragen we u om een notitie. Na kennisgeving van schendingen zal ik dergelijke inhoud onmiddellijk verwijderen.<br><br>
										
<strong>Privacy Policy</strong><br>
Het gebruik van deze website is meestal mogelijk zonder persoonlijke informatie te verstrekken. Voor zover aan mijn zijde persoonlijke gegevens (bijvoorbeeld naam, adres of e-mailadressen) worden verzameld, gebeurt dit zoveel mogelijk altijd op vrijwillge basis. Deze gegevens zullen niet worden bekendgemaakt aan derden zonder uw uitdrukkelijke toestemming. Houd er rekening mee dat datatransmissie via internet (bijvoorbeeld bij communicatie per e-mail) mogelijk beveiligingslekken vertoont. Een volledige bescherming van de gegevens tegen toegang door derden is niet mogelijk. Het gebruik van contactgegevens die zijn gepubliceerd in het kader van de afdrukverplichting van derden voor het verzenden van ongevraagde reclame- en informatiemateriaal, wordt hierbij uitdrukkelijk uitgesloten. De beheerder van de pagina's behoudt zich uitdrukkelijk het recht voor om gerechtelijke stappen te ondernemen in het geval van ongevraagde promotionele informatie, zoals spam-e-mails.
                                        <br><br>
<strong>Contactformulier</strong><br>
Als u ons via het contactformulier vragen stuurt, worden uw gegevens op het aanvraagformulier, inclusief de contactgegevens die u daar heeft verstrekt, opgeslagen om het verzoek te verwerken en in geval van vervolgvragen. We zullen deze informatie niet delen zonder uw toestemming.

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Privacy-Policy Area End -->
					
					
            
					
					
					
        </div>
    </div>
        <!-- Service Details Area End -->
      

  	  <!-- Footer Area -->
        <footer class="footer-area pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3>Contactgegevens</h3>
                            <p>Huisartsenpraktijk Rolde</p>
                            <ul class="footer-contact-list">
                               
                                   
                                  
                                       <a href="https://goo.gl/maps/f5cpJKq8mwQuQUN76" target="_blank"> Zuides 50A • 9451 KD Rolde</a>
                                 
                             
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="footer-widget">
                            <h3>AVG - Copyright</h3>
                            <ul class="footer-list">
                                <li>
                                    <a href="huisartsenpraktijk-rolde-privacyverklaring.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Privacyverklaring
                                    </a>
                                </li> 
                                <li>
                                    <a href="huisartsenpraktijk-rolde-disclaimer.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Disclaimer
                                    </a>
                                </li> 
                                
                             
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget">
                            <h3>Openingstijden</h3>
                            <ul class="open-hours-list">
                                <li>
                                    Ma. t/m Vr.
                                    08:00 - 17:00 uur
                                </li> 
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget ps-2">
                            <div class="footer-logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="Logo">
                                </a>
                            </div>
                            <p></p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->

        <!-- Copy-Right Area -->
        <div class="copy-right-area">
            <div class="container">
                <div class="copy-right-text text-center">
                    <p>
                        Copyright ©2021 Huisartsenpraktijk Rolde. :: Realisatie: 
                        <a href="https://www.blixxum.nl" target="_blank">Blixxum! Design</a> 
                    </p>
                </div>
            </div>
        </div>
        <!-- Copy-Right Area End -->

         <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Datepicker JS -->
        <script src="assets/js/datepicker.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
        
    </body>
</html>
