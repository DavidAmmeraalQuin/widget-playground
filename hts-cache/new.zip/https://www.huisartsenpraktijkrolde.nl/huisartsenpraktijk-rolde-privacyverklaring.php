<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Flaticon CSS --> 
        <link rel="stylesheet" href="assets/fonts/flaticon.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Owl Carousel Min CSS --> 
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <!-- Nice Select Min CSS --> 
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">


        <title>Huisartsenpraktijk Rolde</title>

        <!-- Favicon -->
<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
		
    </head>
    <body>
        <!-- Pre Loader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="spinner"></div>
                </div>
            </div>
        </div>
        <!-- End Pre Loader -->

      	

      <!-- Start Navbar Area -->
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/logo.png" alt="Huisartsenpraktijk Rolde logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/logo.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
								
                               
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link">
                                        Home
                                    </a>
                                </li>
								
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Praktijk 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-spreekuur.php" class="nav-link">
                                                Spreekuur
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-recepten.php" class="nav-link">
                                                Recepten
                                            </a>
                                        </li>
										
																		
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                                Inschrijven
                                            </a>
                                        </li>
										
										  <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-over-ons.php" class="nav-link">
                                                Over ons
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-medewerkers.php" class="nav-link">
                                                Medewerkers
                                            </a>
                                        </li>
										
										 <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-patientenenquete.php" class="nav-link">
                                                Patiëntenenquête
                                            </a>
                                        </li>
										
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-klachtenregeling.php" class="nav-link">
                                                Klachtenregeling
                                            </a>
                                        </li>
										
                                       
                                      
                                    </ul>
                                </li>

                              

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Afspraken 
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-maken.php" class="nav-link">
                                                Afspraak maken 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-afspraak-afzeggen.php" class="nav-link">
                                                Afspraak afzeggen 
                                            </a>
                                        </li>
										 <li class="nav-item">
                                            <a href="https://web.quin.md/assessment?agbCode=01008118" target="_blank" class="nav-link">
                                                Check je gezondheidsklacht 
                                            </a>
                                        </li>
                                      
                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Contact
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Adresgegevens 
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Contactgegevens
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="huisartsenpraktijk-rolde-contact.php" class="nav-link">
                                                Openingstijden 
                                            </a>
                                        </li>
										<li class="nav-item">
                                            <a href="https://web.quin.md/directmessaging?agbCode=01008118" target="_blank" class="nav-link">
                                                Chat met de praktijk 
                                            </a>
                                        </li>
                                    </ul>
                                </li>
								
								  <li class="nav-item">
                                     <a href="mijngezondheidnet.php" class="nav-link">
                                        MijnGezondheid.net
                                    </a>
                                </li>

								  <li class="nav-item">
                                     <a href="huisartsenpraktijk-rolde-formulieren.php" class="nav-link">
                                        Formulieren
                                    </a>
                                </li>

                              
								
								
                            </ul>

                           

                             
                            </div>
                        </div>
                    </nav>
                </div>
            </div>

            <div class="side-nav-responsive">
                <div class="container">
                   
                 

                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        <!-- Inner Banner -->
        <div class="inner-banner inner-bg1">
            <div class="container">
                <div class="inner-title">
                    <h3>Privacyverklaring</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>Privacyverklaring</li>
                    </ul>
                </div>
            </div>
            <div class="inner-banner-shape">
               
            </div>
        </div
        <!-- Inner Banner End -->

       
      <!-- Privacy-Policy Area -->
        <div class="privacy-policy-area pt-100 pb-70">
            <div class="container">
               
                <div class="row pt-45">
                    <div class="col-lg-12">
                        <div class="single-content">
                           
                                  <h4>Privacyverklaring</h4>
									
                                    <div class="text">
										
										Uw persoonsgegevens en privacy in onze huisartsenpraktijk.

 <br><br>

<strong>Algemeen</strong><br>

De AVG( Algemene Verordening Gegevensbescherming) is de nieuwe wet ter bescherming van privacy en persoonsgegevens. Op grond van deze wet heeft een organisatie die met persoonsgegevens werkt bepaalde plichten en heeft degene van wie de gegevens zijn bepaalde rechten. Naast deze algemene wet gelden specifieke regels voor de privacy in de gezondheidszorg. Deze regels staan onder andere vermeld in de Wet geneeskundige behandelingsovereenkomst (WGBO).  Dit privacyreglement is bedoeld om u te informeren over uw rechten en onze plichten die gelden op grond van de AVG en de WGBO.
<br><br>
 

<strong>Huisartsenpraktijk</strong><br>

In onze huisartsenpraktijk kunnen diverse persoonsgegevens van u verwerkt worden. Dit is noodzakelijk om u medisch goed te kunnen behandelen en nodig voor het financieel afhandelen van de behandeling. Daarnaast kan verwerking noodzakelijk zijn voor, bijvoorbeeld, de bestrijding van ernstig gevaar voor uw gezondheid of ter voldoening aan een wettelijke verplichting (bijvoorbeeld het verplicht melden van een besmettelijke ziekte op grond van de Wet Publieke Gezondheid).
<br><br>

<strong>De plichten van de huisartsenpraktijk</strong><br>

Huisartsenpraktijk Rolde  is volgens de AVG de verantwoordelijke voor de verwerking van persoonsgegevens die in de praktijk plaatsvindt. Aan de plichten die daaruit voortkomen, voldoet de praktijk  als volgt. <br>
<br>
Uw gegevens worden voor specifieke doeleinden verzameld:<br>

       •  voor zorgverlening;<br>

       • voor doelmatig beheer en beleid;<br>

       • voor ondersteuning van wetenschappelijk onderzoek, onderwijs en voorlichting.<br>

    • Er vindt in beginsel geen verwerking plaats voor andere doeleinden.
<br>
   •  U wordt op de hoogte gesteld van het feit dat er persoonsgegevens van u verwerkt worden. Dit kan gebeuren door uw zorgverlener, maar ook via een folder of via onze website.
<br>
    • Alle medewerkers binnen huisartsenpraktijk  Rolde hebben zich verplicht om vertrouwelijk om te gaan met uw persoonsgegevens.
<br>
    • Uw persoonsgegevens worden goed beveiligd tegen onbevoegde toegang.
<br>
    • Uw persoonsgegevens worden niet langer bewaard dan noodzakelijk is voor goede zorgverlening.
<br><br>
Voor medische gegevens is deze bewaartermijn in principe 15 jaar (vanaf de laatste behandeling), tenzij langer bewaren noodzakelijk is, bijvoorbeeld voor de gezondheid van uzelf of van uw kinderen. Dit is ter beoordeling van de behandelaar.

 
<br><br>
<strong>Uw heeft als betrokkene de volgende rechten:</strong><br>



•     Het recht om te weten of en welke persoonsgegevens van u verwerkt worden.
<br>
    • Het recht op inzage en afschrift van die gegevens (voor zover de privacy van een ander daardoor niet wordt geschaad).
<br>
    • Het recht op correctie, aanvulling of verwijdering van gegevens indien dat nodig mocht zijn.
<br>
    • Het recht om (gedeeltelijke) vernietiging van uw medische gegevens te vragen. Hieraan kan alleen tegemoet worden gekomen als het bewaren van de gegevens voor een ander niet van aanmerkelijk belang is en de gegevens op grond van een wettelijke regeling niet bewaard moeten blijven.
<br>
    • Het recht op het toevoegen van een eigen verklaring (van medische aard) aan uw dossier.
<br>
    • Het recht om u in bepaalde gevallen tegen de verwerking van uw gegevens te verzetten.
<br><br>
 

Als u gebruik wilt maken van uw rechten, dan kunt u dit middels een aanvraagformulier kenbaar maken aan  Huisartsenpraktijk Rolde. Uw belangen kunnen ook behartigd worden door een vertegenwoordiger (zoals een schriftelijk gemachtigde, of uw curator of mentor).
<br><br>
 

<strong>Toelichting op het aanvraagformulier</strong><br>

U moet er rekening mee  houden dat medische gegevens ingevolge de wet in principe maximaal vijftien jaar bewaard worden. U helpt ons met het opzoeken van uw dossier en het beschermen van uw privacy als u het formulier zo volledig mogelijk invult. De door u ingevulde gegevens worden door ons strikt vertrouwelijk behandeld. Huisartsenpraktijk Rolde is niet aansprakelijk voor fouten in de postbezorging. Indien u er de voorkeur aan geeft om het dossier persoonlijk, of door een gemachtigde, op te halen dan kunt u dit op het formulier aangeven.<br><br>

<strong>Gegevens patiënt</strong><br>

Hierbij vermeldt u de gegevens van de persoon over wie het medisch dossier gaat. De Wet Geneeskundige Overeenkomst (WBGO) beschouwt de patiënt als meerderjarig vanaf 16 jaar. Jongeren vanaf 16 jaar die inzage/afschrift van hun medisch dossier willen, moeten zelf de aanvraag indienen. Indien de patiënt niet meer in leven is, is het verstrekken van de medische gegevens toegestaan indien verondersteld kan worden dat de overledene hiertegen geen bezwaar zou hebben gehad of er sprake is van zwaarwegende belangen om de zwijgplicht van de zorgverlener te doorbreken. Deze beslissing ligt bij de zorgverlener.
<br><br>
 

<strong>Verstrekking van uw persoonsgegevens aan derden</strong><br>

De medewerkers van Huisartsenpraktijk Rolde hebben de verplichting vertrouwelijk met uw persoonsgegevens om te gaan. Dit houdt bijvoorbeeld in dat de zorgverlener voor verstrekking van uw persoonsgegevens uw uitdrukkelijke toestemming nodig heeft. Op deze regel bestaan echter enkele uitzonderingen. Op grond van een wettelijk voorschrift kan de zwijgplicht van de zorgverlener doorbroken worden, maar ook wanneer gevreesd moet worden voor een ernstig gevaar voor uw gezondheid of die van een derde. Bovendien kunnen vastgelegde gegevens, indien noodzakelijk mondeling, schriftelijk of digitaal uitgewisseld worden met andere zorgverleners (bijvoorbeeld de apotheker die een recept verwerkt en zodoende gegevens verstrekt krijgt van de huisarts).

<strong>Uitwisseling gegevens</strong><br>
Bent u ’s avonds of in het weekend op de HAP geweest, dan deelt die op zijn beurt een waarneembericht met de huisartsenpraktijk. Zo weet de huisarts precies met welke klachten u op de HAP bent geweest en wat er naar aanleiding daarvan is ondernomen.
<br><br>
Ook kunnen er medicatiegegevens gedeeld worden met uw apotheek en uw behandelend medisch specialisten. Daarbij gaat het om de medicatie die de huisarts aan u heeft voorgeschreven, maar ook om eventuele intoleranties, contra-indicaties en allergieën (ICA-gegevens). Daar kunnen andere voorschrijvers en verstrekkers van medicatie rekening mee houden. Zo dragen wij als huisartsenpraktijk bij aan medicatieveiligheid.

 <br><br>

<strong>Vraag of klacht</strong><br>

Heeft u een vraag of een klacht? Bijvoorbeeld over met wie wij gegevens delen of onze omgang met uw medische gegevens? Dan gaat uw huisarts hierover graag met u in gesprek.

<br><br>
								
<a href="https://autoriteitpersoonsgegevens.nl/nl/onderwerpen/avg-europese-privacywetgeving/algemene-informatie-avg" target="_blank">Autoriteit Persoonsgegevens</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Privacy-Policy Area End -->
					
					
            
					
					
					
        </div>
    </div>
        <!-- Service Details Area End -->
      

  	  <!-- Footer Area -->
        <footer class="footer-area pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3>Contactgegevens</h3>
                            <p>Huisartsenpraktijk Rolde</p>
                            <ul class="footer-contact-list">
                               
                                   
                                  
                                       <a href="https://goo.gl/maps/f5cpJKq8mwQuQUN76" target="_blank"> Zuides 50A • 9451 KD Rolde</a>
                                 
                             
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="footer-widget">
                            <h3>AVG - Copyright</h3>
                            <ul class="footer-list">
                                <li>
                                    <a href="huisartsenpraktijk-rolde-privacyverklaring.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Privacyverklaring
                                    </a>
                                </li> 
                                <li>
                                    <a href="huisartsenpraktijk-rolde-disclaimer.php">
                                        <i class='bx bxs-chevron-right'></i>
                                        Disclaimer
                                    </a>
                                </li> 
                                
                             
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget">
                            <h3>Openingstijden</h3>
                            <ul class="open-hours-list">
                                <li>
                                    Ma. t/m Vr.
                                    08:00 - 17:00 uur
                                </li> 
                              
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget ps-2">
                            <div class="footer-logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="Logo">
                                </a>
                            </div>
                            <p></p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->

        <!-- Copy-Right Area -->
        <div class="copy-right-area">
            <div class="container">
                <div class="copy-right-text text-center">
                    <p>
                        Copyright ©2021 Huisartsenpraktijk Rolde. :: Realisatie: 
                        <a href="https://www.blixxum.nl" target="_blank">Blixxum! Design</a> 
                    </p>
                </div>
            </div>
        </div>
        <!-- Copy-Right Area End -->

         <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Datepicker JS -->
        <script src="assets/js/datepicker.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
        
    </body>
</html>